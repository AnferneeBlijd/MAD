var asset = {
    helloBG_jpg : "asset/helloBG.jpg",
    start_n_png : "asset/start_n.png",
    start_s_png : "asset/start_s.png",
};

var g_resources = [];
for (var i in asset) {
    g_resources.push(asset[i]);
}